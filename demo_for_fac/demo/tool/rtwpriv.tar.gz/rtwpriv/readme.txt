Q. How to build rtwpriv tool?

A.
[Linux]
Just "make", and you will get executable file "rtwpriv".

[Android - Speradtrum platform]
Step 1. put rtwpriv directory to idh.code/external/.
Step 2. In root directory (idh.code/), run "./mk sp6820gb u adr external/rtwpriv/".
Step 3. The binary is installed on "out/target/product/hsdroid/system/bin/rtwpriv".

